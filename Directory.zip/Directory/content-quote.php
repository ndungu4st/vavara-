<div class="entry-header"> <?php echo apply_filters('supreme_content_format_post_info_',supreme_content_format_post_info()); ?> </div>
<div class="entry-summary">
  <?php the_content(); ?>
</div>
<!-- .entry-summary -->
