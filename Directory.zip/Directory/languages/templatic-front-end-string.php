<input type="hidden" name='templatic' value="<?php 
// Directory/library/functions/comments.php
_e( 'Comment', 'templatic' );  /* line no. 170 */ 
_e( 'Log out of this account', 'templatic' ); /* line no. 172 */ 
_e( 'Log out &raquo;', 'templatic' ); /* line no. 172 */ 
_e( 'Name', 'templatic' ); /* line no. 156 */ 
_e( 'Email', 'templatic' ); /*line no. 157*/ 
_e( 'Website', 'templatic' ); /* line no. 158 */ 
_e( '*', 'templatic' ); /* line no. 152 */ 
_e( 'Leave a Reply', 'templatic' ); /* line no. 177 */ 
_e( 'Add a Review', 'templatic' ); /* line no. 177 */ 
_e( 'Leave a Reply to ', 'templatic' ); /* line no. 178 */ 
_e( 'Add a Review to ', 'templatic' ); /* line no. 178 */ 
_e( 'Click here to cancel reply.', 'templatic' ); /* line no. 179 */ 
_e( 'Post Comment', 'templatic' ); /* line no. 180 */
_e( 'Logged in as', 'templatic' );
_e(' and ','templatic');
_e('View the entire comment','templatic');
// Directory/library/functions/hooks.php
_e('Leave a response', 'templatic' ); /* line no. 47 */
_e('%1$s Response', 'templatic' ); /* line no. 37 */
_e('%1$s Responses', 'templatic' ); /* line no. 37 */
_e(' (Listing owner) ','templatic');
_e('New Claim Submitted','templatic');
_e('Other Information','templatic');
_e('Total Price', 'templatic' );
_e('Payment Details for', 'templatic' );
_e('Type', 'templatic' );
_e('Date','templatic');
_e('Reference Number','templatic');
_e('Account Number','templatic')
_e('Price Package Information','templatic');
_e('Wrong username or password.','templatic');
// Directory/comments.php
_e( 'No Comment', 'templatic' ); /* line no. 30 */ 
_e( 'One Comment', 'templatic' ); /* line no. 30 */
_e( 'Comments', 'templatic' ); /* line no. 30 */
_e( 'No Review', 'templatic' ); /* line no. 34 */
_e( 'One Review', 'templatic' ); /* line no. 34 */
_e( 'Reviews', 'templatic' ); /* line no. 34 */
_e( '1 Comment', 'templatic' ); /* line no. 34 */
_e('Post Review','templatic');
_e('rating','templatic');
_e('ratings','templatic');
_e('Upgraded Successfully','templatic');
_e('Renew','templatic');
_e('| No Comments','templatic');
_e('| 1 Comment','templatic');
_e('| % Comments','templatic');
_e('| Comments Closed','templatic');

// Directory/functions.php
_e('Last Page','templatic');
_e('Next','templatic');
_e('Previous','templatic');
_e('First Page','templatic');


//breadcrumb-trail.php
_e('Home','templatic'); /* line no. 42 */
_e('Search results for','templatic' ); /* line no. 266 */
_e('404 Not Found','templatic' ); /* line no. 269 */ 

/* taxonomy_functions.php */
_e('Published by','templatic');
_e( 'Edit', 'templatic' );
_e( 'Edit ', 'templatic' );
_e('On','templatic');
_e('Categories: ','templatic');
_e('Tags: ','templatic');
_e('[Read More...]', 'templatic');

// Directory/library/functions/widget_functions.php
_e('Mile','templatic');
_e('Kilometer','templatic');
_e('Kilometers','templatic');
_e('Miles','templatic');

// Directory/library/functions/loadpopularpost.php
_e('min','templatic'); /* line no. 73 */
_e('mins','templatic'); /* line no. 74 */
_e('hour','templatic'); /* line no. 75 */
_e('hours','templatic'); /* line no. 76 */
_e('day','templatic'); /* line no. 77 */
_e('days','templatic'); /* line no. 78 */
_e('week','templatic'); /* line no. 79 */
_e('weeks','templatic'); /* line no. 80 */
_e('month','templatic'); /* line no. 81 */
_e('months','templatic'); /* line no. 82 */
_e('year','templatic'); /* line no. 83 */
_e('years','templatic'); /* line no. 84 */
_e('ago','templatic'); /* line no. 132 */
_e('view','templatic'); /* line no. 136 */
_e('views','templatic'); /* line no. 136 */
_e('Visits today','templatic'); /* line no. 136 */

// Directory/library/functions/functions.php
_e('Visited','templatic'); /* line no. 1016 */
_e('time','templatic'); /* line no. 1006 */
_e('times','templatic'); /* line no. 1008 */
_e('Visit','templatic'); /* line no. 1012 */
_e('Visits','templatic'); /* line no. 1014 */
_e('today','templatic'); /* line no. 1017 */
_e('To','templatic'); /* line no. 559 */

// Directory/library/functions/shortcodes.php
_e('Reply', 'templatic' ); /* line no. 233 */
_e('Log in to reply.', 'templatic' ); /* line no. 234 */
_e('%1$s at %2$s', 'templatic' ); /* line no. 161 */

// Tevolution/tmplconnector/monetize/templatic-generalizaion/add_to_favourites.php
_e('Add to favorites','templatic'); /* line no. 54 */
_e('Added','templatic'); /* line no. 55 */
_e("You cannot select more than ",'templatic');
_e(" categories with this package.",'templatic');
// Tevolution/tmplconnector/templatic-connector.php
_e('Package Name','templatic'); /* line no. 884 */
_e('Price','templatic'); /* line no. 885 */
_e('Next Billing will occur on: ','templatic'); /* line no. 896 */
_e('Expires On: ','templatic'); /* line no. 898 */
_e('Edit','templatic'); /* line no. 956 */
_e('Upgrade','templatic'); /* line no. 957 */
_e('Delete','templatic'); /* line no. 963 */
_e('This listing is not published yet, contact site administrator for more details.','templatic');

//Tevolution/tmplconnector/monetize/templatic-claim_ownership/claim_functions.php
_e('Already Claimed','templatic');/* 651*/
_e('Owner Verified Listing','templatic');/*653 */
_e('ERROR: Please enter a username.','templatic');
_e('<strong>ERROR</strong>: This username is invalid.  Please enter a valid username.','templatic');
_e('<strong>ERROR</strong>: This username is already registered, please choose another one.','templatic');
_e('<strong>ERROR</strong>: Please type your e-mail address.','templatic');
_e('<strong>ERROR</strong>: The email address isn&#8217;t correct.','templatic');
_e('<strong>ERROR</strong>: This email is already registered, please choose another one.','templatic');
_e('You have subscribed to this package but your transaction is not approved yet. Please %s contact%s the administrator of the site for more details.','templatic');
_e('Pay With','templatic');
// Tevolution/tmplconnector/shortcodes/shortcode_advance_search.php
_e('Select Categories','templatic'); /* line no. 48 */

// Primary Menu 
_e('Register','templatic');
_e('Login','templatic');

// Tevolution/tmplconnector/monetize/templatic-custom-fields/success.php
_e('You are going to update a post that will cost you ','templatic');
_e('for','templatic');
_e('days','templatic');
_e("You are going to update your entry. To make any changes, please press the 'Go back and edit' button below.",'templatic');
_e("<p>Hello [#to_name#]</p><p>Here's some info about your payment...</p><p>[#transaction_details#]</p><p>If you'll have any questions about this payment please send an email to [#admin_email#]</p><p>Thanks!,<br/>[#site_name#]</p>",'templatic');
_e("<p>Howdy [#to_name#] ,</p><p>You have received a payment of [#payable_amt#] on [#site_name#]. Details are available below</p><p>[#transaction_details#]</p><p>Thanks,<br/>[#site_name#]</p>",'templatic');
_e("Thank you! We have successfully received the submitted information.",'templatic');
_e("Click here",'templatic');
_e("for a preview of the submitted content.",'templatic');
_e("View your submitted information",'templatic');
_e("Thank you! We have successfully received your PreBank payment request.",'templatic');
_e("To complete the transaction please transfer ",'templatic');
_e("Please include the following number as reference:",'templatic');
_e("Thank you!",'templatic');
_e("<p>Howdy [#to_name#] ,</p><p>Payment from [#user_login#] is pending for the new listing they submitted on your site as they selected pre bank transfer as their preferred payment method.</p><p><p>You can view details below [#transaction_details#]</p> <p>You can contact [#user_login#] for status of the payment.</p><p>Thanks!<br/>[#site_name#]</p>",'templatic');
_e('Payment Method','templatic' );
_e('Paid amount','templatic' );
_e('Status','templatic' );
_e('Submitted Successfully','templatic');
_e('Upgraded Successfully','templatic');
_e('Updated Successfully','templatic');

// Tevolution/tmplconnector/monetize/templatic-custom_taxonomy/taxonomy_functions.php
_e('Send to friend','templatic'); /* line no. 469 */
_e('Send inquiry','templatic'); /* line no. 475 */
_e('Add to favorites','templatic');
_e('Looking For ...','templatic');
_e('Location','templatic');
_e('Mail to a friend','templatic');
_e('Send Inquiry','templatic');
_e(' Head over to the ','templatic');
_e('Form','templatic');
_e( ' to add one.', 'templatic' );

// Tevolution-Directory/functions/widget_functions.php
_e('What?','templatic'); /* line no. 317 */
_e('Pay &amp; Publish','templatic');
_e('Visits today','templatic');
_e('Read more','templatic');

// Tevolution-Directory\listing\listing.php
_e('Listings','templatic'); /* line no. 9 */
// Tevolution-Directory\templates\directory-listing-single-content.php
_e('Listing Information','templatic'); /* line no. 9 */

// Tevolution/tmplconnector/monetize/templatic-generalization/general_functions.php
_e('My Favorites','templatic'); /* line no. 94 */
_e('Favorites','templatic'); 

// Tevolution/tmplconnector/monetize/templatic-custom_fields/custom_fields_function.php
_e("Thank you for your submission!",'templatic');
_e('Information Submitted URL','templatic');
_e('Category','templatic');
_e('Title','templatic');
_e('Description','templatic');
_e('Excerpt','templatic');
_e('Images','templatic');
_e('You are going to submit post for ','templatic');
_e('days','templatic');
_e('You are going to upgrade your post with ','templatic');
_e('package which will cost you','templatic');
_e('You are going to submit a post that will cost you ','templatic');
_e('for','templatic');
_e("This is the preview of your submitted information. To make any changes, please press the 'Go back and edit' button below.",'templatic'); //143
_e('You are going to update your entry.','templatic'); //147
_e('Log out','templatic');
_e('PREV','templatic');
_e('NEXT','templatic');
_e('Based on','templatic');
_e('Please enter your friend\'s name','templatic');
_e('Please enter your friend\'s valid email address','templatic');
_e('Please enter your valid email address','templatic');
_e('Are you really sure want to DELETE this post? Deleted post can not be recovered later.','templatic');
_e('Oops! Please make sure you have filled all the mandatory fields.','templatic');
_e("Please upload at least 1 image to the gallery !",'templatic');
/* Submit form */
_e('Please select Category','templatic');
_e('Please Enter title','templatic');
_e('Please enter phone number','templatic');
_e('Please Enter Address','templatic');
_e('Please Enter content','templatic');
_e("Please provide your email address",'templatic');
_e("Please provide valid email address",'templatic');
_e("Oops!, looks like you forgot to enter a value in some compulsory field",'templatic');
_e('Your submitted Information','templatic');
_e('Please Select Price Package','templatic');
_e('Select your %s package','templatic');
_e('You have subscribed to the %s package.','templatic');
_e('Please accept Terms and Conditions.','templatic');
_e('Incorrect username','templatic');
// Tevolution-LocationManager\functions\manage_functions.php
_e('Please select country name','templatic');
_e('Please select city name','templatic');
_e('Please select state name','templatic');
_e('Select Country','templatic');
_e('Select Country','templatic');
_e('Select State','templatic');
_e('Select City','templatic');
_e('Select Payment Method','templatic');
_e('States not available','templatic');
_e('City not available','templatic');
_e('read more','templatic');
_e('User name','templatic');
_e('review','templatic');
_e('reviews','templatic');
_e('Please wait, We are taking you to your nearest city.','templatic');
/* register form */
_e('Please Enter E-mail','templatic');
_e('Please Enter User name','templatic');
_e('Please Enter %s','templatic');
_e('Your profile is updated successfully.','templatic');
_e('Your Profile','templatic');
_e('Thank you for purchasing a subscription plan','templatic');
_e('Thank you for registration! Please check your mail to get your login information.','templatic');

/* Contact form mail page-template/contact-us.php */
_e("Dear",'templatic');
_e("You have an inquiry message. Here are the details",'templatic');
_e("Name",'templatic');
_e("Email",'templatic');
_e("Message",'templatic');
_e('Check your e-mail for your new password.','templatic');
_e('<strong>ERROR</strong>: There is no user registered with that email address.','templatic');

_e("User name must be minimum 4 character long",'templatic');
_e("Usernames should not contain space.",'templatic');
_e('Search For','templatic');
_e('Your name','templatic');
_e('Email Address','templatic');
_e('Website','templatic');
_e('Comments','templatic');

/* 	Tevolution/tmplconnector/monetize/templatic-custom_fields/category.php */
_e('Select Category','templatic'); /* line : 74 */

/* Tevolution/tmplconnector/monetize/templatic-custom_fields/language.php */
_e('Update Now','templatic'); /* line : 9 */
_e('Payment Pending For Upgrade Request: #','templatic');


_e('Dear','templatic');
_e("Claim verified for - ",'templatic');
_e('The Claim for the','templatic');
_e(' has been verified.','templatic');
_e('You can login with the following credentials :','templatic');
_e('Username:','templatic');
_e('Password:','templatic');
_e("You can login from [#site_login_url#] or copy this link and paste it to your browser's address bar: ",'templatic');
_e('Thanks,','templatic');


/* Tevolution/tmplconnector/monetize/templatic-custom_fields/post_upgrade_pay.php */
_e('<p>Dear [#to_name#],</p>','templatic');
_e('<p>Your ','templatic');
_e(' has been updated by you . Here is the information about the ','templatic');
_e('</p>[#information_details#]<br><p>[#site_name#]</p>','templatic');
_e('has been renew by you . Here is the information about the','templatic');
_e('View more detail of','templatic');
_e('Payment Status: <b>Pending</b>','templatic');
_e('Payment Method:' ,'templatic');
_e('Payment Status: <b>Success</b>','templatic');
_e('Bank Name: ','templatic');
_e('Account Number: ','templatic');
_e('Thank you for submitting your %s at our site, your %s request has been updated successfully.','templatic');
_e('Log in','templatic');
_e( 'You must be','templatic');
_e('logged in','templatic');
_e(' to post a comment.', 'templatic' );
_e('I am a','templatic');
_e('Preview This','templatic');
_e('We have found these results for listings matching your search criteria.','templatic');
_e('From:','templatic');
_e('<i>Previous</i>','templatic');
_e('<i>Next</i>','templatic');
_e('Visited %s times','templatic');
_e(" Visits today",'templatic');
_e("Set Address on Map",'templatic');
_e('Previous', 'templatic' );
_e('Next', 'templatic' );
_e('Please Enter ','templatic');
_e('Posted in %s','templatic');
_e('Posted In','templatic');
_e('Package type','templatic');
_e('Pay per subscription','templatic');
_e('Pay per post','templatic');
_e('Validity','templatic');
_e('Recurring Charges','templatic'); 
_e('Coupon added successfully.','templatic');
_e('Added Successfully','templatic'); /* (breadcrumb string) plugins\Tevolution\tmplconnector\templatic-connector.php */
_e('Submission received successfully, thank you for listing with us.','templatic'); /* Tevolution\tmplconnector\monetize\templatic-custom_fields\language.php */
_e('Tagged In ','templatic');
_e('A','templatic');_e('B','templatic');_e('B','templatic');_e('C','templatic');_e('D','templatic');_e('E','templatic');_e('F','templatic');_e('G','templatic');_e('H','templatic');_e('I','templatic');_e('J','templatic');_e('K','templatic');_e('L','templatic');_e('M','templatic');_e('N','templatic');_e('O','templatic');_e('P','templatic');_e('Q','templatic');_e('R','templatic');_e('S','templatic');_e('T','templatic');_e('U','templatic');_e('V','templatic');_e('W','templatic');_e('X','templatic');_e('Y','templatic');_e('Z','templatic');
_e('Continue','templatic');
_e('Preview','templatic');
_e('Please select Country','templatic');
_e('Please select State','templatic');
_e('Please select City','templatic');
_e('Approved','templatic');
_e('Pending','templatic');
_e('Welcome %s, submit your listing details.','templatic');
_e('Add Review','templatic');
_e('unlimited','templatic');
_e('<span>Posted In</span> %s','templatic');
_e('Renew Successfully Information','templatic');
_e('Amount','templatic');
_e("Please enter a valid email address",'templatic');
_e('Free','templatic');
_e('Homepage','templatic');
_e('Category page','templatic');
_e('unlimited','templatic');
_e('Sign Up','templatic');
_e('Verified','templatic');
_e('Beds ','templatic');
_e('Baths ','templatic');
_e('sq.ft','templatic');
_e('This package allows you to add %d listings, you have already added %d. You still have %d listings left in your package.','templatic');
_e('%s Category','templatic');
_e('Please Select %s','templatic');
_e('Print','templatic');
_e('Claim Ownership','templatic');
_e('Hi ','templatic');
_e('Package for this post has been expired.','templatic');
_e('Listing Owner','templatic');
_e('<p>Dear [#to_name#],</p>
		<p>%s has been renew on your site. Here is the information about the %s:</p>
		[#information_details#]
		<br>
		<p>[#site_name#]</p>','templatic');
_e('Bank Name','templatic');
_e('description in two lines (will be shown on listing pages)','templatic');
_e("Values must be all numbers.",'templatic');
_e('Transaction ID','templatic');
_e('You have now upgraded to a new package %s You paid %s to upgrade your package.','templatic');
_e('Your request has been updated successfully.','templatic');
?>"/>